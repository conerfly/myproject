//
//  ApplierInfoViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>


@interface ApplierInfoViewController : UIViewController

@property (nonatomic, strong) PFObject *user;
@property (nonatomic, strong) PFObject *request;
@property (nonatomic) BOOL isApplyer;

@property (weak, nonatomic) IBOutlet UILabel *userName;
@property (weak, nonatomic) IBOutlet UILabel *credit;

@property (weak, nonatomic) IBOutlet UIButton *accept;
@property (weak, nonatomic) IBOutlet UIButton *cancel;

- (IBAction)accept:(id)sender;
- (IBAction)cancel:(id)sender;

@end
