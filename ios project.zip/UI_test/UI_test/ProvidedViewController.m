//
//  ProvidedViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "ProvidedViewController.h"

@interface ProvidedViewController ()

@end

@implementation ProvidedViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    
    self.appDelegate = [[UIApplication sharedApplication] delegate];
}

-(void)viewWillAppear:(BOOL)animated
{
    self.requests = [[NSMutableArray alloc] init];
    
    [self.tableView reloadData];
    
    PFObject *user = [PFUser currentUser];
    NSString *username = user[@"username"];
    
    PFQuery *requestQuery = [PFQuery queryWithClassName:@"request"];
    
    [requestQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error)
     {
         if (!error)
         {
             for (PFObject *request in objects)
             {
                 if ([request[@"provider"] isEqualToString:username])
                 {
                         [self.requests addObject:request];
                 }
             }
             NSLog(@"request number: %lu", (unsigned long)[self.requests count]);
             [self.tableView reloadData];
         }
         else
             NSLog(@"error: %@", error);
     }];}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDelegate Methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.requests count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PFObject *request = [self.requests objectAtIndex:[indexPath row]];
    ProvidedTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"provided" forIndexPath:indexPath];
    
    if (cell)
    {
        cell.request = [self.requests objectAtIndex:[indexPath row]];
        cell.title.text = [NSString stringWithFormat: @"Title: %@", request[@"title"]];
        cell.days.text = [NSString stringWithFormat:@"Days: %d", [request[@"day"] intValue]];
        cell.tickets.text = [NSString stringWithFormat:@"Tickets: %d", [request[@"rewards"] intValue]];
        if ([request[@"inProcess"] boolValue])
            cell.statusImage.image = [UIImage imageNamed:@"green"];
        else
            cell.statusImage.image = [UIImage imageNamed:@"yellow"];
    }
    else
        NSLog(@"no cell");
    return cell;
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"fromProvide"])
    {
        PFObject *temp = [(ProvidedTableViewCell *)sender request];
        
        RequestStatuViewController *RSVC = [segue destinationViewController];
        RSVC.isFromProvide = YES;
        RSVC.titleText = [[(ProvidedTableViewCell*)sender title] text];
        RSVC.descriptionText = temp[@"description"];
        RSVC.daysText = temp[@"day"];
        RSVC.ticketsText = temp[@"rewards"];
        RSVC.imageAsset = temp[@"images"];
        
        CLLocation *tempLocation = [[CLLocation alloc] initWithLatitude:[temp[@"location"]latitude] longitude:[temp[@"location"]longitude]];
        
        RSVC.location = tempLocation;
        RSVC.isApplying = [temp[@"isApplying"]boolValue];
        
        RSVC.request = temp;
        NSLog(@"%@", RSVC.request[@"title"]);
        NSLog(@"from provide");
    }
}


@end
