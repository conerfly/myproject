//
//  RequestStatuViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "RequestStatuViewController.h"

@interface RequestStatuViewController ()

@end

@implementation RequestStatuViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.appDelegate = [[UIApplication sharedApplication] delegate];
}

-(void)viewWillAppear:(BOOL)animated
{
    if (self.isFromNew)
    {
        self.submit.hidden = NO;
    }
    else if (self.isFromSearch)
    {
        self.apply.hidden = NO;
    }
    else
    {
        if (![self.request[@"inProcess"] boolValue])
        {
            self.cancelNotInProcess.hidden = NO;
        }
        else
        {
            if ([self.request[@"isAccepted"]boolValue])
            {
                self.cancel.hidden = NO;
                self.finish.hidden = NO;
            }
            else
            {
                if (![self.request[@"applyer"] isEqualToString:self.appDelegate.user[@"username"]])
                {
                    self.considering.hidden = NO;
                   
                }
                else
                {
                    self.cancelNotInProcess.hidden = NO;
                }
            }
             self.helper.hidden = NO;
        }
    }
    
    self.titleLabel.text = self.titleText;
    self.descriptionTextView.text = self.descriptionText;
    
    if (self.location == nil)
    {
        NSLog(@"don't have location in request status view");
    }
    else
        NSLog(@"Location in request status view: %@", self.location);
    
    //this is not on the main thread
    CLGeocoder *geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:self.location completionHandler:^(NSArray *placemarks, NSError *error)
     {
         if(placemarks.count)
         {
             NSDictionary *dictionary = [[placemarks objectAtIndex:0] addressDictionary];
             self.streetText = [dictionary valueForKey:@"Street"];
             self.cityText = [dictionary valueForKey:@"City"];
             self.stateText = [dictionary valueForKey:@"State"];
             self.zipText = [dictionary valueForKey:@"ZIP"];
             
             NSLog(@"street text: %@", self.streetText);
             
             self.streetLabel.text = self.streetText;
             self.CSZLabel.text = [NSString stringWithFormat:@"%@, %@, %@", self.cityText, self.stateText, self.zipText];
             self.daysLabel.text = [NSString stringWithFormat: @"Days : %@", self.daysText];
             self.ticketsLabel.text = [NSString stringWithFormat:@"tickets : %@", self.ticketsText];
         }
         else
             NSLog(@"%@", error);
     }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)submit:(id)sender
{
    
    PFObject *newRequest = [PFObject objectWithClassName:@"request"];
    newRequest[@"title"] = self.titleText;
    newRequest[@"description"] = self.descriptionText;
    newRequest[@"inProcess"] = @NO;
    newRequest[@"day"] = [NSNumber numberWithInt: [self.daysText intValue]];
    newRequest[@"rewards"] = [NSNumber numberWithInt:[self.ticketsText intValue]];
    

    PFObject *user = [PFUser currentUser];
    NSString *username = user[@"username"];
    [newRequest setObject:username forKey:@"creater"];
    
    if (self.isApplying)
    {
        [newRequest setObject:username forKey:@"applyer"];
        
        //newRequest[@"isApplying"] = @YES;
        int ticket = [self.appDelegate.user[@"ticket"] intValue];
        ticket -= [self.ticketsText intValue];
        self.appDelegate.user[@"ticket"] = [NSNumber numberWithInt:ticket];
        
        int numOfApply = [self.appDelegate.user[@"numOfApply"] intValue];
        numOfApply += 1;
        self.appDelegate.user[@"numOfApply"] = [NSNumber numberWithInt:numOfApply];
    }
    else
    {
        [newRequest setObject:username forKey:@"provider"];
        
        //newRequest[@"isApplying"] = @NO;
        int numOfProvide = [self.appDelegate.user[@"numOfProvide"] intValue];
        numOfProvide += 1;
        self.appDelegate.user[@"numOfProvide"] = [NSNumber numberWithInt:numOfProvide];
    }
    [self.appDelegate.user saveInBackground];
    
    CLLocationCoordinate2D coordinate = [self.location coordinate];
    PFGeoPoint *geoPoint = [PFGeoPoint geoPointWithLatitude:coordinate.latitude longitude:coordinate.longitude];
    [newRequest setObject:geoPoint forKey:@"location"];
    
    if (self.imageAsset != nil)
        newRequest[@"images"] = self.imageAsset;
    
    newRequest[@"isAccepted"] = @NO;
    newRequest[@"finish"] = @0;

    [newRequest saveInBackgroundWithBlock:^(BOOL succeeded, NSError *error)
     {
         if (!error)
         {
             NSLog(@"new request saved");
         }
         else
             NSLog(@"error: %@", error);
     }];
    
    
    //LoginViewController * logInView = (LoginViewController *) [self.storyboard instantiateViewControllerWithIdentifier:@"logIn"];
    self.submit.hidden = YES;
    
}

- (IBAction)apply:(id)sender
{
    PFObject *user = [PFUser currentUser];
    
    if (self.request[@"applyer"] == nil)
    {
        self.request[@"applyer"] = user[@"username"];
        int ticket = [self.appDelegate.user[@"ticket"] intValue];
        ticket -= [self.ticketsText intValue];
        self.appDelegate.user[@"ticket"] = [NSNumber numberWithInt:ticket];
    }
    else
    {
        self.request[@"provider"] = user[@"username"];
    }
    
    [self.appDelegate.user saveInBackground];
    
    self.request[@"inProcess"] = @YES;
    
    [self.request saveInBackground];
    
    self.apply.hidden = YES;
}

- (IBAction)cancelSmall:(id)sender
{
    [self.appDelegate.user incrementKey:@"failed"];
    [self deleteRequest];
    [self.appDelegate.user saveInBackground];
    
    self.cancel.hidden = YES;
}

- (IBAction)cancelBig:(id)sender
{
    [self.appDelegate.user incrementKey:@"failed"];
    [self deleteRequest];
    [self.appDelegate.user saveInBackground];
    
    self.cancelNotInProcess.hidden = YES;
}

- (IBAction)helperInfo:(id)sender
{
    //[self performSegueWithIdentifier:@"userInfo" sender:self];
}

- (IBAction)finish:(id)sender
{
    [self.appDelegate.user incrementKey:@"succed"];
    [self.request incrementKey: @"finish"];
    if ([self.request[@"finish"] intValue] == 2)
    {
        PFQuery *query = [PFUser query];
        [query whereKey:@"username" equalTo:self.request[@"provider"]];
        NSArray *array = [query findObjects];
        PFObject* provider = [array lastObject];
        [provider incrementKey:@"ticket" byAmount:self.request[@"rewards"]];
        
        [self deleteRequest];
    }
}

-(void)deleteRequest
{
    if ([self.request[@"creater"] isEqualToString:self.appDelegate.user[@"username"]])
    {
        if ([self.request[@"provider"] isEqualToString:self.request[@"creater"]])
        {
            [self.appDelegate.user incrementKey:@"numOfProvide" byAmount:@-1];
        }
        else
            [self.appDelegate.user incrementKey:@"numOfApply" byAmount:@-1];
        
        [self.request deleteInBackground];
    }
    else
    {
        if ([self.request[@"provider"] isEqualToString:self.appDelegate.user[@"username"]])
        {
            [self.request removeObjectForKey:@"provider"];
        }
        else
        {
            [self.request removeObjectForKey:@"applyer"];
        }
        self.request[@"inProcess"] = @NO;
        self.request[@"isAccepted"] = @NO;
        [self.request saveInBackground];
    }
    
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"showImage"])
    {
        ImageViewController *IVC = [segue destinationViewController];
        IVC.imageAssets = self.imageAsset;
    }
    if ([segue.identifier isEqualToString:@"userInfo"])
    {
        ApplierInfoViewController *AIVC = [segue destinationViewController];
        if ([self.request[@"provider"] isEqualToString:self.appDelegate.user[@"username"]])
        {
            PFQuery *query = [PFUser query];
            [query whereKey:@"username" equalTo:self.request[@"applyer"]];
            NSArray *array = [query findObjects];
            AIVC.user = [array lastObject];
            AIVC.isApplyer = YES;
        }
        else
        {
            PFQuery *query = [PFUser query];
            [query whereKey:@"username" equalTo:self.request[@"provider"]];
            NSArray *array = [query findObjects];
            AIVC.user = [array lastObject];
            AIVC.isApplyer = NO;
        }
        AIVC.request = self.request;
    }
}



@end
