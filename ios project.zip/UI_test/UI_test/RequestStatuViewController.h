//
//  RequestStatuViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <Parse/Parse.h>

#import "ImageViewController.h"
#import "ApplierInfoViewController.h"
#import "AppDelegate.h"

@interface RequestStatuViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *helper;
@property (weak, nonatomic) IBOutlet UIButton *cancel;
@property (weak, nonatomic) IBOutlet UIButton *finish;
@property (weak, nonatomic) IBOutlet UIButton *apply;
@property (weak, nonatomic) IBOutlet UIButton *submit;
@property (weak, nonatomic) IBOutlet UIButton *cancelNotInProcess;



@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITextView *descriptionTextView;
@property (weak, nonatomic) IBOutlet UILabel *streetLabel;
@property (weak, nonatomic) IBOutlet UILabel *CSZLabel;
@property (weak, nonatomic) IBOutlet UILabel *daysLabel;
@property (weak, nonatomic) IBOutlet UILabel *ticketsLabel;
@property (weak, nonatomic) IBOutlet UILabel *considering;

- (IBAction)submit:(id)sender;
- (IBAction)apply:(id)sender;
- (IBAction)cancelSmall:(id)sender;
- (IBAction)cancelBig:(id)sender;
- (IBAction)helperInfo:(id)sender;
- (IBAction)finish:(id)sender;

- (void)deleteRequest;


@property(nonatomic, strong) NSString *titleText;
@property(nonatomic, strong) NSString *descriptionText;
@property(nonatomic, strong) NSString *daysText;
@property(nonatomic, strong) NSString *ticketsText;

@property(nonatomic, strong) NSString *streetText;
@property(nonatomic, strong) NSString *cityText;
@property(nonatomic, strong) NSString *stateText;
@property(nonatomic, strong) NSString *zipText;
@property(nonatomic) BOOL isApplying;

@property (nonatomic, strong) PFObject* request;
@property (nonatomic, strong) CLLocation *location;
@property (nonatomic, strong) NSArray *imageAsset;
@property (nonatomic, strong) AppDelegate *appDelegate;



@property (nonatomic) BOOL isFromNew;
@property (nonatomic) BOOL isFromApply;
@property (nonatomic) BOOL isFromProvide;
@property (nonatomic) BOOL isFromSearch;

@end
