//
//  MainInfoViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

#import "NewRequestViewController.h"
#import "AppDelegate.h"

@interface MainInfoViewController : UIViewController

@property(nonatomic, strong) PFObject *getUserName;
@property(nonatomic, strong) PFObject *user;
@property(nonatomic, strong) NSString *userName;
@property(nonatomic) int ticket;

@property (weak, nonatomic) IBOutlet UILabel *ticketLabel;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *applyRequestNum;
@property (weak, nonatomic) IBOutlet UILabel *providedRequestNum;

@property (weak, nonatomic) IBOutlet UIButton *needSomething;
@property (weak, nonatomic) IBOutlet UIButton *provideSomething;

- (IBAction)newNeed:(id)sender;
- (IBAction)newProvided:(id)sender;

-(PFObject *)getUser: (NSString *)userName;

@end
