//
//  ApplierInfoViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "ApplierInfoViewController.h"

@interface ApplierInfoViewController ()

@end

@implementation ApplierInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSLog(@"user name: %@", self.user[@"username"]);
}

- (void) viewWillAppear:(BOOL)animated
{
    self.userName.text = self.user[@"username"];
    CGFloat credit = ([self.user[@"succed"]intValue]/[self.user[@"failed"]intValue])*100;
    self.credit.text = [NSString stringWithFormat:@"Credit: %.2f%%", credit];
    
    if (![self.request[@"creater"] isEqualToString:self.user[@"username"]])
    {
        self.accept.hidden = YES;
        self.cancel.hidden = YES;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)accept:(id)sender
{
    self.request[@"isAccepted"] = @YES;
}

- (IBAction)cancel:(id)sender
{
    if (self.isApplyer)
    {
        [self.user incrementKey:@"ticket" byAmount:[NSNumber numberWithInt:[self.request[@"rewards"]intValue]]];
        [self.request removeObjectForKey:@"applyer"];
    }
    else
        [self.request removeObjectForKey:@"provider"];
    [self.user saveInBackground];
    [self.request saveInBackground];
}
@end
