//
//  ChooseLocationViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 26/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "ChooseLocationViewController.h"

@interface ChooseLocationViewController ()

@end

@implementation ChooseLocationViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.streetOneTextField.delegate = self;
    self.streetTwoTextField.delegate = self;
    self.cityTextField.delegate = self;
    self.stateTextField.delegate = self;
    self.zipTextField.delegate = self;
    
    self.appDelegate = [[UIApplication sharedApplication] delegate];
    
    self.placeDictionary = [[NSMutableDictionary alloc] init];
    
    self.mapView.delegate = self;
    self.mapView.mapType = MKMapTypeStandard;
    [self.mapView setShowsUserLocation:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)setLocation:(id)sender
{
    [self updatePlaceDictionary];
    [self updateMap];
}

- (IBAction)useCurrentLocation:(id)sender
{
    if (self.annotation != nil)
    {
        [self.mapView removeAnnotation:self.annotation];
        self.annotation = nil;
    }
    self.mapView.showsUserLocation = YES;
    
    self.appDelegate.tempLocation = self.mapView.userLocation.location;
    self.errorLabel.text = @"";
}

-(void)updatePlaceDictionary
{
    NSString *street;
    street = [self.streetOneTextField.text stringByAppendingString:self.streetTwoTextField.text];
    [self.placeDictionary setValue:street forKey:@"Street"];
    [self.placeDictionary setValue:self.cityTextField.text forKey:@"City"];
    [self.placeDictionary setValue:self.stateTextField.text forKey:@"State"];
    [self.placeDictionary setValue:self.zipTextField.text forKey:@"ZIP"];
}

-(void)updateMap
{
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder geocodeAddressDictionary:self.placeDictionary completionHandler:^(NSArray *placemarks, NSError *error) {
        if([placemarks count])
        {
            self.mapView.showsUserLocation = NO;
            
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            self.appDelegate.tempLocation = placemark.location;
            CLLocationCoordinate2D coordinate = self.appDelegate.tempLocation.coordinate;
            [self.mapView setCenterCoordinate:coordinate animated:YES];
            self.annotation = [[MKPointAnnotation alloc] init];
            _annotation.coordinate = coordinate;
            _annotation.title = @"Set location here";
            _annotation.subtitle = [NSString stringWithFormat:@"%@, %@, %@, %@", [self.placeDictionary valueForKey:@"Street"], [self.placeDictionary valueForKey:@"City"], [self.placeDictionary valueForKey:@"State"], [self.placeDictionary valueForKey:@"ZIP"]];
            
            [self.mapView addAnnotation:_annotation];
            
            self.errorLabel.hidden = YES;
        } else {
            self.errorLabel.hidden = NO;
            self.errorLabel.text = @"could not find location";
        }
    }];
}

#pragma mark MKMapViewDelegate Methods

- (void) mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    CLLocationCoordinate2D cLocation = [userLocation coordinate];
    MKCoordinateRegion zoomRegion = MKCoordinateRegionMakeWithDistance(cLocation, 1000, 1000);
    [self.mapView setRegion:zoomRegion animated:YES];
}

#pragma mark - UITextFieldDelegate Methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"addLocation"])
    {
        NewRequestViewController *NRVC = [segue destinationViewController];
        NRVC.applyerLocation = self.selectedLocation;
    }
    else
        NSLog(@"segue test");
}
*/


@end
