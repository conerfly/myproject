//
//  ProvidedTableViewCell.h
//  UI_test
//
//  Created by Zhengyu Yuan on 27/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

@interface ProvidedTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *statusImage;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *tickets;
@property (weak, nonatomic) IBOutlet UILabel *days;

@property (nonatomic, strong)PFObject *request;
@end
