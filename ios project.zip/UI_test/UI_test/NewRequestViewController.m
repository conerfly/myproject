//
//  NewRequestViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "NewRequestViewController.h"

@interface NewRequestViewController ()

@end

@implementation NewRequestViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.requestTitle.delegate = self;
    self.description.delegate = self;
    self.days.delegate = self;
    self.tickets.delegate = self;
    self.description.text = @"this is the description for the request";
    self.description.textColor = [UIColor lightGrayColor];
    
    self.appDelegate = [[UIApplication sharedApplication] delegate];
    self.user = [self.appDelegate user];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)numberCheck:(UITextField *)sender
{
    BOOL isValid = NO;
    NSCharacterSet *alphaNumbersSet = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *stringSet = [NSCharacterSet characterSetWithCharactersInString:sender.text];
    isValid = [alphaNumbersSet isSupersetOfSet:stringSet];
    if (sender.text.length > 0 && isValid)
    {
        isValid=YES;
    }
    else
    {
        isValid=NO;
    }
    return isValid;
}

- (IBAction)addImages:(id)sender
{
    if (self.requestTitle.text.length == 0)
    {
        self.errorLabel.text = @"please enter a title for this request";
    }
    else
    {
        if (!self.assets)
            self.assets = [[NSMutableArray alloc] init];
        
        CTAssetsPickerController *picker = [[CTAssetsPickerController alloc] init];
        picker.assetsFilter         = [ALAssetsFilter allAssets];
        picker.showsCancelButton    = (UI_USER_INTERFACE_IDIOM() != UIUserInterfaceIdiomPad);
        picker.delegate             = self;
        picker.selectedAssets       = [NSMutableArray arrayWithArray:self.assets];
        [self presentViewController:picker animated:YES completion:nil];
    }
}

- (IBAction)addLocation:(id)sender
{
    if (self.tickets.text.length == 0)
    {
        self.errorLabel.text = @"enter other infor before choosing location";
    }
    else
    {
        [self performSegueWithIdentifier:@"addLocation" sender:self];
    }
}

- (IBAction)confirm:(id)sender
{
    self.applyerLocation = self.appDelegate.tempLocation;
    if (self.applyerLocation == nil)
    {
        self.errorLabel.text = @"please select a location for this request";
    }
    else
    {
        self.errorLabel.text = [NSString stringWithFormat:@"selected %lu images, location setted", (unsigned long)[self.assets count]];
        NSLog(@"ready to save this request");
        NSLog(@"%@", self.appDelegate.tempLocation);
        self.confirmBtn.hidden = YES;
        [self performSegueWithIdentifier:@"fromNew" sender:self];
    }
}

#pragma mark UIImagePickerControllerDelegate Methods

- (void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    self.chosenImage = info[UIImagePickerControllerOriginalImage];
    
    //save image to temporary array
    if (self.images == nil)
    {
        self.images = [[NSMutableArray alloc] init];
    }
    [self.images addObject:self.chosenImage];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UITextFieldDelegate methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == self.requestTitle)
    {
        [textField resignFirstResponder];
        if (textField.text.length == 0)
        {
            self.errorLabel.text = @"please enter a title for this request";
        }
    }
    if (textField == self.days)
    {
        [textField resignFirstResponder];
        if ([self numberCheck:textField])
        {
            NSLog(@"ok");
        }
        else
            NSLog(@"wrong");
        
        
        
        if (textField.text.length == 0 || ![self numberCheck:textField])
        {
            self.errorLabel.text = @"please enter a valid time";
            textField.text = @"";
        }
        else
        {
            if (self.requestTitle.text.length == 0)
            {
                self.errorLabel.text = @"please enter a title for this request";
                textField.text = @"";
            }
            else
                self.errorLabel.text = @"";
        }
        
    }
    if (textField == self.tickets)
    {
        [textField resignFirstResponder];
        
        if(textField.text.length == 0 || ![self numberCheck:textField])
        {
            self.errorLabel.text = @"please enter a valid number";
            textField.text = @"";
        }
        else
        {
            if (self.requestTitle.text.length == 0)
            {
                self.errorLabel.text = @"please enter a title for this request";
                textField.text = @"";
            }
            else
                self.errorLabel.text = @"";
            
            int ticket = [[self.user objectForKey:@"ticket"] intValue];
            int enterTicket = [self.tickets.text intValue];
            if (self.isApplying)
            {
                if (enterTicket > ticket)
                {
                    self.errorLabel.text = @"you don't have enough tickets";
                    self.tickets.text = @"";
                }
            }

        }
    }
    return YES;
}

#pragma mark - UITextViewDelegate methods

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    if (self.requestTitle.text.length == 0)
    {
        self.errorLabel.text = @"please enter a title for this request";
        [textView resignFirstResponder];
    }
    else
    {
        if ([textView.text isEqualToString:@"this is the description for the request"])
        {
            textView.text = @"";
            textView.textColor = [UIColor blackColor];
        }
        [textView becomeFirstResponder];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    [textView resignFirstResponder];
    if (textView.text.length == 0)
    {
        self.errorLabel.text = @"we do need decription of this request for others";
    }
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [[event allTouches] anyObject];
    if ([self.description isFirstResponder] && [touch view] != self.description) {
        [self.description resignFirstResponder];
    }
    [super touchesBegan:touches withEvent:event];
}

#pragma mark - Assets Picker Delegate

- (BOOL)assetsPickerController:(CTAssetsPickerController *)picker isDefaultAssetsGroup:(ALAssetsGroup *)group
{
    return ([[group valueForProperty:ALAssetsGroupPropertyType] integerValue] == ALAssetsGroupSavedPhotos);
}

- (void)assetsPickerController:(CTAssetsPickerController *)picker didFinishPickingAssets:(NSArray *)assets
{
    [picker.presentingViewController dismissViewControllerAnimated:YES completion:nil];
    
    self.assets = [NSMutableArray arrayWithArray:assets];
    if (self.images == nil)
    {
        self.images = [[NSMutableArray alloc] init];
    }
    for (int i = 0; i < [self.assets count]; i ++)
    {
        self.chosenImage = [UIImage imageWithCGImage: [[self.assets objectAtIndex:i]thumbnail]];
        self.imageData = UIImageJPEGRepresentation(self.chosenImage, 0.5f);
        [self.images addObject:self.imageData];
    }
}

- (BOOL)assetsPickerController:(CTAssetsPickerController *)picker shouldSelectAsset:(ALAsset *)asset
{
    if (picker.selectedAssets.count >= 3)
    {
        UIAlertView *alertView =
        [[UIAlertView alloc] initWithTitle:@"Attention"
                                   message:@"Please select not more than 10 assets"
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        
        [alertView show];
    }
    
    if (!asset.defaultRepresentation)
    {
        UIAlertView *alertView =
        [[UIAlertView alloc] initWithTitle:@"Attention"
                                   message:@"Your asset has not yet been downloaded to your device"
                                  delegate:nil
                         cancelButtonTitle:nil
                         otherButtonTitles:@"OK", nil];
        
        [alertView show];
    }
    
    return (picker.selectedAssets.count < 10 && asset.defaultRepresentation != nil);
}



#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"fromNew"])
    {
        RequestStatuViewController *RSVC = [segue destinationViewController];
        RSVC.isFromNew = YES;
        RSVC.titleText = self.requestTitle.text;
        RSVC.descriptionText = self.description.text;
        RSVC.daysText = self.days.text;
        RSVC.ticketsText = self.tickets.text;
        RSVC.location = self.appDelegate.tempLocation;
        RSVC.imageAsset = self.images;
        RSVC.isApplying = self.isApplying;
    }
}


@end
