//
//  SignupViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "SignupViewController.h"

@interface SignupViewController ()

@end

@implementation SignupViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.signUpName.delegate = self;
    self.signUpPassword.delegate = self;
    self.signUpConfirm.delegate = self;
    self.signUpPhone.delegate = self;
    
    
    self.signUpPassword.secureTextEntry = YES;
    self.signUpConfirm.secureTextEntry = YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)begin:(id)sender
{
    [PFUser logInWithUsernameInBackground:self.signUpName.text password:self.signUpPassword.text
                                block:^(PFUser *user, NSError *error)
                                    {
                                        // Do stuff after successful login.
                                        self.errorLabel.text = @"";
                                        
                                        AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
                                        appDelegate.user = [self getUser:self.signUpName.text];
                                        
                                        [self performSegueWithIdentifier:@"signUp" sender:self];
                                    }];
}

-(BOOL)phoneCheck:(UITextField *)sender
{
    BOOL isValid = NO;
    NSCharacterSet *alphaNumbersSet = [NSCharacterSet decimalDigitCharacterSet];
    NSCharacterSet *stringSet = [NSCharacterSet characterSetWithCharactersInString:sender.text];
    isValid = [alphaNumbersSet isSupersetOfSet:stringSet];
    if (sender.text.length==10 && isValid)
    {
        isValid=YES;
    }
    else
    {
        isValid=NO;
    }
    return isValid;
}

#pragma mark - UITextFieldDelegate Methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (textField == self.signUpName)
    {
        NSLog(@"%lu", (unsigned long)self.signUpName.text.length);
        if (self.signUpName.text.length < 5)
        {
            self.errorLabel.text = @"choose a longer user name (5)";
            [self.signUpName resignFirstResponder];
        }
        else
        {
            self.errorLabel.text = @"";
            [self.signUpName resignFirstResponder];
            [self.signUpPassword becomeFirstResponder];
        }

    }
    if (textField == self.signUpPassword)
    {
        if (self.signUpName.text.length == 0)
        {
            self.errorLabel.text = @"choose a user name first";
            [self.signUpPassword resignFirstResponder];
            self.signUpPassword.text = @"";
        }
        if (self.signUpPassword.text.length < 5)
        {
            self.errorLabel.text = @"choose a longer password";
            self.signUpPassword.text = @"";
            [self.signUpPassword resignFirstResponder];
        }
        else
        {
            [self.signUpPassword resignFirstResponder];
            [self.signUpConfirm becomeFirstResponder];
        }

    }
    if (textField == self.signUpConfirm)
    {
        [self.signUpConfirm resignFirstResponder];
        if ([self.signUpPassword.text isEqualToString:self.signUpConfirm.text])
        {
            [self.signUpPhone becomeFirstResponder];
            self.errorLabel.text = @"";
        }
        else
        {
            self.errorLabel.text = @"The password doesn't match";
            self.signUpConfirm.text = @"";
        }
        
    }
    if (textField == self.signUpPhone)
    {
        if (self.signUpName.text.length == 0)
        {
            [self.signUpPhone resignFirstResponder];
            self.signUpPhone.text = @"";
            self.errorLabel.text = @"choose a user name first";
        }
        else
        {
            if (![self phoneCheck:textField] && self.signUpPhone.text.length != 10) {
                self.errorLabel.text = @"please enter vaild phone number";
                self.signUpPhone.text = @"";
                [self.signUpPhone resignFirstResponder];
            }
            else
            {
                PFUser *User = [PFUser user];
                User.username = self.signUpName.text;
                User.password = self.signUpPassword.text;
                
                [User signUpInBackgroundWithBlock:^(BOOL succeeded, NSError *error)
                 {
                     if (!error)
                     {
                         // Hooray! Let them use the app now.
                         self.errorLabel.text = @"valid user name";
                         
                         PFObject *user = [self getUser:self.signUpName.text];
                         
                         NSString *name = user[@"username"];
                         NSLog(@"%@", name);
                         
                         user[@"ticket"] = @3;
                         user[@"phone"] = self.signUpPhone.text;
                         user[@"numOfApply"] = @0;
                         user[@"numOfProvide"] = @0;
                         user[@"succed"] = @1;
                         user[@"failed"] = @1;
                         [user saveInBackground];
                         
                     } else
                     {
                         NSString *errorString = [error userInfo][@"error"];
                         self.errorLabel.text = errorString;
                         // Show the errorString somewhere and let the user try again.
                     }
                 }];
                [self.signUpPhone resignFirstResponder];
            }
        }
    }
    return YES;
}

-(PFObject *)getUser:(NSString *)userName
{
    PFQuery *query = [PFUser query];
    [query whereKey:@"username" equalTo:userName];
    NSArray *array = [query findObjects];
    PFObject* user = [array lastObject];
    
    return user;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"signUp"])
    {
        TabbarController *TBVC = segue.destinationViewController;
        MainInfoViewController *MIVC = (MainInfoViewController *)([TBVC viewControllers][0]);
        MIVC.user = [self getUser:self.signUpName.text];
    }
    
}
*/

@end
