//
//  MainInfoViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "MainInfoViewController.h"

@interface MainInfoViewController ()

@end

@implementation MainInfoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"this is view did load");
    self.getUserName = [PFUser currentUser];
    self.user = [self getUser:[self.getUserName objectForKey:@"username"]];
    
}

-(void)viewWillAppear:(BOOL)animated
{
        NSLog(@"this is view will appear");
    
    self.userName= [self.user objectForKey:@"username"];
    self.ticket = [[self.user objectForKey:@"ticket"] intValue];
    
    self.userNameLabel.text = [NSString stringWithFormat:@"Hello %@", self.userName];
    self.ticketLabel.text = [NSString stringWithFormat:@"Tickets: %d", self.ticket];
    self.applyRequestNum.text = [NSString stringWithFormat:@"Applied Request : %d", [[self.user objectForKey:@"numOfApply"] intValue]];
    self.providedRequestNum.text = [NSString stringWithFormat:@"Provided Request : %d", [[self.user objectForKey:@"numOfProvide"] intValue]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(PFObject *)getUser:(NSString *)userName
{
    PFQuery *query = [PFUser query];
    [query whereKey:@"username" equalTo:userName];
    NSArray *array = [query findObjects];
    PFObject* user = [array lastObject];
    
    return user;
}

- (IBAction)newNeed:(id)sender
{
    [self performSegueWithIdentifier:@"newRequest" sender:self.needSomething];
}

- (IBAction)newProvided:(id)sender
{
    [self performSegueWithIdentifier:@"newRequest" sender:self.provideSomething];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    NewRequestViewController *NRVC;
    
    if ([segue.identifier isEqualToString:@"newRequest"])
    {
        if ([segue.destinationViewController isKindOfClass:[NewRequestViewController class]])
        {
            NRVC = segue.destinationViewController;
            
            if (sender == self.needSomething)
            {
                NSLog(@"need");
                NRVC.isApplying = YES;
            }
            else if(sender == self.provideSomething)
            {
                NSLog(@"provide");
                NRVC.isApplying = NO;
            }
            else
                NSLog(@"nothing");
        }
        else
            NSLog(@"cannot determin the destinationViewController");
    }
}



@end
