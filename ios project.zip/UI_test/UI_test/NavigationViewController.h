//
//  NavigationViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 29/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationViewController : UINavigationController

@end
