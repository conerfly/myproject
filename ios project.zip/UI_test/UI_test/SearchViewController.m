//
//  SearchViewController.m
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import "SearchViewController.h"

@interface SearchViewController ()

@end

@implementation SearchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    
    self.appDelegate = [[UIApplication sharedApplication] delegate];    
}

-(void)viewWillAppear:(BOOL)animated
{
    self.requests = [[NSMutableArray alloc] init];
    
    PFObject *user = [PFUser currentUser];
    NSString *username = user[@"username"];
    
    PFQuery *requestQuery = [PFQuery queryWithClassName:@"request"];
    //[requestQuery whereKey:@"starter" equalTo:username];
    
    [requestQuery findObjectsInBackgroundWithBlock:^(NSArray *objects, NSError *error)
     {
         if (!error)
         {
             for (PFObject *request in objects)
             {
                 if (![request[@"creater"] isEqualToString:username])
                 {
                     if (![request[@"inProcess"]boolValue])
                     {
                         [self.requests addObject:request];
                     }
                 }
             }
             NSLog(@"request number: %lu", (unsigned long)[self.requests count]);
             [self.tableView reloadData];
         }
         else
             NSLog(@"error: %@", error);
     }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableViewDelegate Methods

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.requests count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SearchTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"search" forIndexPath:indexPath];
    
    if (cell)
    {
        cell.request = [self.requests objectAtIndex:[indexPath row]];
        cell.title.text = [NSString stringWithFormat: @"Title: %@", cell.request[@"title"]];
        cell.days.text = [NSString stringWithFormat:@"Days: %d", [cell.request[@"day"] intValue]];
        cell.tickets.text = [NSString stringWithFormat:@"Tickets: %d", [cell.request[@"rewards"] intValue]];
        if (cell.request[@"provider"] != nil)
            cell.statusImage.image = [UIImage imageNamed:@"blue"];
        else
            cell.statusImage.image = [UIImage imageNamed:@"red"];
    }
    else
        NSLog(@"no cell");
    return cell;
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    if ([segue.identifier isEqualToString:@"fromSearch"])
    {
        PFObject *temp = [(SearchTableViewCell *)sender request];
        
        RequestStatuViewController *RSVC = [segue destinationViewController];
        RSVC.isFromSearch = YES;
        RSVC.titleText = [[(SearchTableViewCell*)sender title] text];
        NSLog(@"test navigation : %@", RSVC.ticketsText);
        RSVC.descriptionText = temp[@"description"];
        RSVC.daysText = temp[@"day"];
        RSVC.ticketsText = temp[@"rewards"];
        RSVC.imageAsset = temp[@"images"];
        
        CLLocation *tempLocation = [[CLLocation alloc] initWithLatitude:[temp[@"location"]latitude] longitude:[temp[@"location"]longitude]];
        
        RSVC.location = tempLocation;
        RSVC.isApplying = [temp[@"isApplying"]boolValue];
        RSVC.request = temp;

    }
}

@end