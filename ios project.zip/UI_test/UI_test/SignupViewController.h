//
//  SignupViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

#import "AppDelegate.h"
#import "MainInfoViewController.h"
#import "TabbarController.h"

@interface SignupViewController : UIViewController <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *signUpName;
@property (weak, nonatomic) IBOutlet UITextField *signUpPassword;
@property (weak, nonatomic) IBOutlet UITextField *signUpConfirm;
@property (weak, nonatomic) IBOutlet UITextField *signUpPhone;

@property (weak, nonatomic) IBOutlet UILabel *errorLabel;


- (IBAction)begin:(id)sender;

-(BOOL)phoneCheck:(UITextField *)sender;
-(PFObject *)getUser: (NSString *)userName;

@end
