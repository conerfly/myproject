//
//  AppliedViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>
#import <CoreLocation/CoreLocation.h>

#import "AppDelegate.h"
#import "RequestTableViewCell.h"
#import "RequestStatuViewController.h"


@interface AppliedViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) AppDelegate *appDelegate;
@property (nonatomic, strong) NSMutableArray *requests;


@property (weak, nonatomic) IBOutlet UITableView *tableView;



@end
