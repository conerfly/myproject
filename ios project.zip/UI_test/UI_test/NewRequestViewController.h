//
//  NewRequestViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

#import "AppDelegate.h"
#import "ChooseLocationViewController.h"
#import "RequestStatuViewController.h"
#import "CTAssetsPickerController.h"
#import "CTAssetsPageViewController.h"

@interface NewRequestViewController : UIViewController<UITextFieldDelegate, UITextViewDelegate, CTAssetsPickerControllerDelegate>

@property(nonatomic, strong)PFObject *user;
@property(nonatomic) BOOL isApplying;
@property (nonatomic, strong) UIImage *chosenImage;
@property (nonatomic, strong) NSData *imageData;
@property (nonatomic,strong) NSMutableArray *images;
@property (nonatomic, copy) NSArray *assets;
@property (nonatomic, strong) CLLocation *applyerLocation;
@property (nonatomic, strong) AppDelegate *appDelegate;

@property (weak, nonatomic) IBOutlet UITextField *requestTitle;
@property (weak, nonatomic) IBOutlet UITextView *description;
@property (weak, nonatomic) IBOutlet UITextField *days;
@property (weak, nonatomic) IBOutlet UITextField *tickets;

@property (weak, nonatomic) IBOutlet UILabel *errorLabel;
@property (weak, nonatomic) IBOutlet UIButton *confirmBtn;

- (IBAction)addImages:(id)sender;
- (IBAction)addLocation:(id)sender;
- (IBAction)confirm:(id)sender;

- (BOOL)numberCheck:(UITextField *)sender;


@end
