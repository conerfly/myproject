//
//  LoginViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 23/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Parse/Parse.h>

#import "AppDelegate.h"
#import "TabbarController.h"
#import "MainInfoViewController.h"

@interface LoginViewController : UIViewController <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *userNameTextField;
@property (weak, nonatomic) IBOutlet UITextField *passwordTextField;
@property (weak, nonatomic) IBOutlet UILabel *errorLabel;

- (IBAction)signIn:(id)sender;
-(PFObject *)getUser: (NSString *)userName;

- (void)logIn;

@end
