//
//  ChooseLocationViewController.h
//  UI_test
//
//  Created by Zhengyu Yuan on 26/10/2014.
//  Copyright (c) 2014 Zhengyu Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

#import "AppDelegate.h"
#import "NewRequestViewController.h"

@interface ChooseLocationViewController : UIViewController<UITextFieldDelegate, CLLocationManagerDelegate, MKMapViewDelegate>

@property (weak, nonatomic) IBOutlet UILabel *streetOneLabel;
@property (weak, nonatomic) IBOutlet UILabel *streetTwoLabel;
@property (weak, nonatomic) IBOutlet UILabel *cityLabel;
@property (weak, nonatomic) IBOutlet UILabel *stateLabel;
@property (weak, nonatomic) IBOutlet UILabel *zipLabel;
@property (weak, nonatomic) IBOutlet UILabel *errorLabel;

@property (weak, nonatomic) IBOutlet UITextField *streetOneTextField;
@property (weak, nonatomic) IBOutlet UITextField *streetTwoTextField;
@property (weak, nonatomic) IBOutlet UITextField *cityTextField;
@property (weak, nonatomic) IBOutlet UITextField *stateTextField;
@property (weak, nonatomic) IBOutlet UITextField *zipTextField;

@property (weak, nonatomic) IBOutlet UIButton *currentLocation;
@property (weak, nonatomic) IBOutlet UIButton *setLocation;

@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (nonatomic, strong) NSMutableDictionary *placeDictionary;
@property (nonatomic, strong) MKPointAnnotation *annotation;
@property (nonatomic, strong) AppDelegate* appDelegate;


- (IBAction)setLocation:(id)sender;
- (IBAction)useCurrentLocation:(id)sender;

-(void)updatePlaceDictionary;
-(void)updateMap;
@end
